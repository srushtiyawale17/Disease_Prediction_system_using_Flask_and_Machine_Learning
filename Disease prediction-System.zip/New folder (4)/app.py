import csv
from flask import Flask, render_template, request, redirect, url_for, jsonify, flash
import diseaseprediction
import os
import pymysql
from db_config import mysql


app = Flask(__name__)
app.secret_key = 'your_secret_key' 

@app.context_processor
def inject_img_path():
    img_path = 'pics/'  
    return {'img_path': img_path}


with open('templates/Testing.csv', newline='') as f:
        reader = csv.reader(f)
        symptoms = next(reader)
        symptoms = symptoms[:len(symptoms)-1]

@app.route('/')
def dropdown():
         return render_template('navbar.html')

@app.route('/consultant')
def consultant():
        return render_template('consultant.html')

@app.route('/service')
def service():
        return render_template('service.html')

@app.route('/default',methods=['GET'])
def default():
        return render_template('default.html', symptoms=symptoms)
 
@app.route('/navbar')
def navbar():
        return render_template('navbar.html')

@app.route('/booking')
def booking():
        return render_template('booking.html')

@app.route('/contact')
def contact():
        return render_template('contact.html')

@app.route('/disease_predict', methods=['POST'])
def disease_predict():
    selected_symptoms = []
    if(request.form['Symptom1']!="") and (request.form['Symptom1'] not in selected_symptoms):
        selected_symptoms.append(request.form['Symptom1'])
    if(request.form['Symptom2']!="") and (request.form['Symptom2'] not in selected_symptoms):
        selected_symptoms.append(request.form['Symptom2'])
    if(request.form['Symptom3']!="") and (request.form['Symptom3'] not in selected_symptoms):
        selected_symptoms.append(request.form['Symptom3'])
    if(request.form['Symptom4']!="") and (request.form['Symptom4'] not in selected_symptoms):
        selected_symptoms.append(request.form['Symptom4'])
    if(request.form['Symptom5']!="") and (request.form['Symptom5'] not in selected_symptoms):
        selected_symptoms.append(request.form['Symptom5'])

#database connectivity code
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM doctor_info")
    rows = cursor.fetchall()
    doctorsdata = []
    for row in rows:
        content = {'Id': row['Id'], 'Disease': row['Disease'], 'DoctorName': row['DoctorName']}
        doctorsdata.append(content)

    disease = diseaseprediction.dosomething(selected_symptoms)
    return render_template('disease_predict.html',disease=disease,symptoms=symptoms,doctorsdata=doctorsdata)


@app.route('/submit', methods=["GET","POST"])
def add_user():
    cursor = None
    conn = None
    try:        
        _name = request.form['inputName']
        _age = request.form['inputage']
        _cont = request.form['contact']
        _doc = request.form['doctor']
        _dis = request.form['disease']
        _add = request.form['address']
        _date = request.form['date']
        _date = request.form['date']
        if _name and _age and _cont and _doc and _dis and _add and _date and request.method == 'POST':
            sql = "INSERT INTO user_info(Username,Age,UserContact,Disease,DoctorName,Address,AppointmentDate) VALUES(%s, %s, %s,%s,%s,%s,%s)"
            data = (_name, _age, _cont,_doc,_dis,_add,_date)
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute(sql, data)
            conn.commit()
            flash('User added successfully!')
            return redirect('/')
        else:
            flash('Error while adding user') 
            return redirect('/booking') 
    except Exception as e:
        print(e)
        flash('Error while adding user')  
        return redirect('/booking')  
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

if __name__ == '__main__':
    app.run(debug=True)