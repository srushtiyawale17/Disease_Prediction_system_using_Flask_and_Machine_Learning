from flaskext.mysql import MySQL
from flask import Flask                #This will create an instance of the MySQL extension that you can use to interact
                                       #with your MySQL database within your Flask application.

app = Flask(__name__)
app.secret_key = "secret key"

mysql = MySQL()

# MySQL configurations
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = 'riteshy'
app.config['MYSQL_DATABASE_DB'] = 'diseaseprediction'
app.config['MYSQL_DATABASE_HOST'] = 'localhost'
mysql.init_app(app)
