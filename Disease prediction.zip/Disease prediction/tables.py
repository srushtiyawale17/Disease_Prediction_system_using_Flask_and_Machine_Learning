from flask_table import Table, Col, LinkCol
 
class Results(Table):
    Id = Col('Id', show=False)
    Disease = Col('Disease')
    DoctorName = Col('DoctorName')

