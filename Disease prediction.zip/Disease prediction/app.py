import csv
from tables import  Results
from flask import Flask, render_template,request,redirect,url_for,jsonify
import diseaseprediction
import os
import pymysql
from db_config import mysql
#import mySQLdb

app = Flask(__name__)
#conn = MySQLdb.connect(host='localhost',user='root',password='',db='disease_database')



with open('templates/Testing.csv', newline='') as f:
        reader = csv.reader(f)
        symptoms = next(reader)
        symptoms = symptoms[:len(symptoms)-1]

@app.route('/')
def dropdown():
         image_paths = ['pics/hospitalLogo.png']
         image_paths1 = ['pics/banner1.jpeg']
         image_paths2 = ['pics/banner2.jpg']
         image_paths3 = ['pics/bookappointmentbanner.jpg']
         image_paths4 = ['pics/banner3.png']
         return render_template('navbar.html', image_paths=image_paths, image_paths1=image_paths1, image_paths2=image_paths2, image_paths3=image_paths3,image_paths4=image_paths4)




@app.route('/disease_predict', methods=['POST'])
def disease_predict():
    selected_symptoms = []
    if(request.form['Symptom1']!="") and (request.form['Symptom1'] not in selected_symptoms):
        selected_symptoms.append(request.form['Symptom1'])
    if(request.form['Symptom2']!="") and (request.form['Symptom2'] not in selected_symptoms):
        selected_symptoms.append(request.form['Symptom2'])
    if(request.form['Symptom3']!="") and (request.form['Symptom3'] not in selected_symptoms):
        selected_symptoms.append(request.form['Symptom3'])
    if(request.form['Symptom4']!="") and (request.form['Symptom4'] not in selected_symptoms):
        selected_symptoms.append(request.form['Symptom4'])
    if(request.form['Symptom5']!="") and (request.form['Symptom5'] not in selected_symptoms):
        selected_symptoms.append(request.form['Symptom5'])

        
    conn = mysql.connect()
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM doctor_info")
    rows = cursor.fetchall()
    doctorsdata = []
    for row in rows:
        content = {'Id': row['Id'], 'Disease': row['Disease'], 'DoctorName': row['DoctorName']}
        doctorsdata.append(content)

    disease = diseaseprediction.dosomething(selected_symptoms)
    return render_template('disease_predict.html',disease=disease,symptoms=symptoms,doctorsdata=doctorsdata)

@app.route('/consultant')
def consultant():
        image_paths = ['pics/hospitalLogo.png']
        return render_template('consultant.html',image_paths=image_paths)

@app.route('/service')
def service():
        image_paths = ['pics/hospitalLogo.png']
        image_paths1 = ['pics/']
        return render_template('service.html',image_paths=image_paths,image_paths1=image_paths1)

@app.route('/default',methods=['GET'])
def default():
        image_paths1 = ['pics/']
        return render_template('default.html', symptoms=symptoms)
 
@app.route('/navbar')
def navbar():
        return render_template('navbar.html')

@app.route('/contact')
def contact():
        image_paths = ['pics/hospitalLogo.png']
        return render_template('contact.html',image_paths=image_paths)


if __name__ == '__main__':
    app.run(debug=True)